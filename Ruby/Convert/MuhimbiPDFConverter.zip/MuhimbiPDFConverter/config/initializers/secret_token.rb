# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
MuhimbiPDFConverter::Application.config.secret_token = 'f98f6401df0287950ad8ea62c38ecc29cfb6348a914df31eae0b9d8a1a43f0c246975fce31d70fecdfbdc3b1f68a793eead4fc342c8233cd9a4afe3381f06c2e'
